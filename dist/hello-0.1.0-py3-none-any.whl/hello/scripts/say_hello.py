from colorama import Fore, Back, Style

def main():
    print(Fore.RED + "Hello!")
    Style.RESET_ALL


if __name__ == '__main__':
    main()
